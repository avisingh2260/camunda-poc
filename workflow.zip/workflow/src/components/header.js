// src/components/Header.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Toolbar, Typography, Button } from '@mui/material';
import { AppBar } from 'stp001-mui-toolkit';
import Logo from "../assets/steward-logo.svg";
import { useAuth } from '../services/AuthContext';
function Header() {
    const [logoSrc, setLogoSrc] = useState(Logo);
    const { user,logout } = useAuth();
    useEffect(() => {
        setLogoSrc(Logo);
    }, []);
    return (
        <AppBar position="static" color="secondary">
            <Toolbar>
                <Typography variant="h6" sx={{ flexGrow: 1 }}>
                    <img src={logoSrc} alt="Logo" />
                </Typography>
                {null!=user &&
                <Button component={Link} to="/" sx={{
                    color: '#FFFFFF',
                    '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}>
                    <label>Dashboard</label>
                </Button>
                }   
                {null!=user && user.role == 'camuser' &&
                    <Button component={Link} to="/form" sx={{
                        color: '#FFFFFF',
                        '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                    }}>

                        <label>New Form</label>
                    </Button>
                }
                 { null!=user && (
                    <Button component={Link} to="/login" sx={{
                        color: '#FFFFFF',
                        '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                    }}>

                        <label>Logout</label>
                    </Button>
                 )}
            </Toolbar>
        </AppBar>
    );
}

export default Header;