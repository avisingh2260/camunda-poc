import React from 'react';
import { Box, styled } from '@mui/material';

const ProgressContainer = styled(Box)({
  display: 'flex',
  width: '100%',
  height: '40px',
  margin: '20px 0',
  alignItems: 'center',
});

const ProgressSegment = styled(Box)(({ theme, status, reversed }) => ({
  flex: 1,
  height: '100%',
  clipPath: reversed
    ? 'polygon(25% 0%, 100% 0%, 100% 100%, 25% 100%, 0% 50%)'
    : 'polygon(0% 0%, 75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%)',
  backgroundColor: 
    status === 'completed' ? '#0C3752' :
    status === 'active' ? '#2A7CB5' :
    '#D3D3D3',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: status === 'pending' ? 'black' : 'white',
  fontWeight: 'bold',
  fontSize: '12px',
  marginRight: reversed ? 0 : '-10px',
  '&:first-of-type': {
    clipPath: 'polygon(0% 0%, 75% 0%, 100% 50%, 75% 100%, 0% 100%)',
  },
}));

const Spacer = styled(Box)({
  width: '20px',
});

export const FormStages = {
  CAM: 0,
  FA_APPROVAL: 1,
  DBD_APPROVAL: 2,
  HO_APPROVAL: 3,
  COMPLETED: 4
};

const FormProgress = ({ currentStage }) => {
  const stages = [
    { key: FormStages.CAM, label: 'CAM' },
    { key: FormStages.FA_APPROVAL, label: 'FA Approval' },
    { key: FormStages.DBD_APPROVAL, label: 'DBD Approval' },
    { key: FormStages.HO_APPROVAL, label: 'Home Office Approval' },
  ];

  const getStageStatus = (stageKey) => {
    if (stageKey < currentStage) return 'completed';
    if (stageKey === currentStage) return 'active';
    return 'pending';
  };

  const isValidStage = stages.some(stage => stage.key === currentStage);
  return (
    <ProgressContainer>
      {stages.map((stage, index) => (
        <React.Fragment key={stage.key}>
          {index === stages.length - 1 && <Spacer />}
          <ProgressSegment 
            status={getStageStatus(stage.key)}
            reversed={stage.reversed}
          >
            {stage.label}
          </ProgressSegment>
        </React.Fragment>
      ))}
    </ProgressContainer>
  );
};

export default FormProgress;