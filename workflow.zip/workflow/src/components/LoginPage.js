import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Button, 
  TextField, 
  Container, 
  Typography, 
  Box 
} from '@mui/material';
import { useAuth } from '../services/AuthContext';

const LoginPage = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const handleLogin = (e) => {
    e.preventDefault();
    // Dummy role assignment based on username
    let role;
    if (username.toLowerCase().includes('fauser1') || username.toLowerCase().includes('fauser2')) {
      role = 'fauser';
    } else if (username.toLowerCase().includes('dbduser')) {
      role = 'dbduser';
    } else if (username.toLowerCase().includes('camuser')) {
      role = 'camuser';
    } else if (username.toLowerCase().includes('houser')) {
      role = 'houser';
    }
     else {
      role = 'guest';
    }
    login(username, role);
    console.log(`Logged in as ${username} with role: ${role}`);
    navigate('/');
    // Here you would typically handle authentication and role assignment
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5">
          Login
        </Typography>
        <Box component="form" onSubmit={handleLogin} sx={{ mt: 1 }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="username"
            label="Username"
            name="username"
            autoComplete="username"
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 ,color:"#0C3752"}}
          >
            Sign In
          </Button>
        </Box>
      </Box>
    </Container>
  );
};

export default LoginPage;