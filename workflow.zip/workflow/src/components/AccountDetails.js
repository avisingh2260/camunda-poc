import React from 'react';
import { useParams } from 'react-router-dom';
import { Typography, Container, Paper, Box } from '@mui/material';

function AccountDetails() {
  let { accountNumber } = useParams();

  return (
    <Container maxWidth="lg">
      <Paper elevation={3} sx={{ my: 4, p: 3 }}>
        <Box sx={{ mb: 3 }}>
          <Typography variant="h4" gutterBottom sx={{ color: '#2A7CB5' }}>
            Account Details
          </Typography>
          <Typography variant="h6" gutterBottom>
            Account Number: {accountNumber}
          </Typography>
        </Box>
        <Box>
          <Typography variant="body1" paragraph>
            This is a placeholder for the account details page.
          </Typography>
        </Box>
      </Paper>
    </Container>
  );
}

export default AccountDetails;
