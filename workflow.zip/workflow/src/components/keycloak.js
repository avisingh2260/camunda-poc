import Keycloak from 'keycloak-js';

const keycloak = new Keycloak({
    url: 'http://localhost:18080/auth',
    realm: 'camunda-platform',
    clientId: 'react-app'
});

export const initKeycloak = () => {
    return keycloak.init({
        onLoad: 'login-required',
        silentCheckSsoRedirectUri: window.location.origin + '/silent-check-sso.html'
    });
};

export { keycloak };