import React, { useState, useEffect } from 'react';
import {
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Grid,
    TextField,
    TablePagination,
    Box,
    IconButton,
    InputAdornment,
    Container,
    Button,
    Tooltip
} from '@mui/material';

import {
    Table,
    Typography,
} from 'stp001-mui-toolkit';
import { Link as RouterLink } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import ArrowDropUp from '@mui/icons-material/ArrowDropUp';
import FilterListIcon from '@mui/icons-material/FilterList';
import RefreshIcon from '@mui/icons-material/Refresh';
import { keycloak } from './keycloak';
import { createProcessVariablesQuery, createProcessQuery } from '../model/ProcessVariablesQuery';
import axios from 'axios';
import Keycloak from 'keycloak-js';
import { useAuth } from '../services/AuthContext';
import { useNavigate } from 'react-router-dom';
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    '&.MuiTableCell-head': {
        backgroundColor: '#2A7CB5',
        color: theme.palette.common.white,
        fontWeight: 'bold',
        padding: '8px',
        width: '9%', // Adjust this value to fit your needs
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
        border: 0,
    },
    '&:hover': {
        backgroundColor: theme.palette.action.selected,
    },
}));


const TaskListView = () => {
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(25);
    const [search, setSearch] = useState('');
    const [isAuthenticated, setIsAuthenticated] = useState(keycloak.authenticated);
    const [processesWithVariables, setProcessesWithVariables] = useState([]);
    const [token, setToken] = useState(null);
    const { user } = useAuth();
    const [sortColumn, setSortColumn] = useState('');
    const [sortDirection, setSortDirection] = useState('asc');
    const [filters, setFilters] = useState({});
    const FormStages = {
        CAM: 0,
        FA_APPROVAL: 1,
        DBD_APPROVAL: 2
    };
    const columns = [
        { id: 'clientFirstName', label: 'Client Name', width: '20%' },
        { id: 'formName', label: 'Form Name', width: 'auto' },
        { id: 'accountNumber', label: 'Account Number' },
        { id: 'approvingWealthManager', label: 'Advisor Name' },
        { id: 'division', label: 'Division' },
        { id: 'branch', label: 'Branch' },
        { id: 'firstName', label: 'Submitted By' },
        { id: 'startDate', label: 'Created At' },
        { id: 'owner', label: 'Owner' },
        { id: 'status', label: 'Status' },
        { id: 'action', label: 'Action' },
    ];
    const [currentStage, setCurrentStage] = useState(FormStages.CAM);
    const navigate = useNavigate();
    useEffect(() => {
        if (isAuthenticated) {
            fetchProcessesAndVariables();
        }
    }, [isAuthenticated]);

    keycloak.onTokenExpired = () => {
        keycloak.updateToken(30).catch(() => {
            console.error('Failed to refresh token');
        });
    };
    const fetchProcesses = async () => {
        try {
            const query = createProcessQuery();
            const queryObject = query.toJSON();
            const tok = undefined == keycloak.token ? token : keycloak.token
            const response = await axios.post('http://localhost:8081/v1/process-instances/search', query, {
                headers: {
                    Authorization: `Bearer ${tok}`
                }
            });

            // Check if response.data is an array
            if (Array.isArray(response.data.items)) {
                const filteredProcesses = response.data.items.filter(process => process.bpmnProcessId === "form-demo");

                return filteredProcesses;
            } else {
                console.error('Response data is not an array:', response.data.items);
                return [];
            }
        } catch (error) {
            console.error('Error fetching processes:', error);
            return [];
        }
    };
    const fetchProcessVariables = async (processId) => {
        try {
            const query = createProcessVariablesQuery(processId);
            const queryObject = query.toJSON();
            const tok = undefined == keycloak.token ? token : keycloak.token
            const response = await axios.post(`http://localhost:8081/v1/variables/search`, queryObject, {
                headers: {
                    Authorization: `Bearer ${tok}`
                }
            });
            return response.data;
        } catch (error) {
            console.error(`Error fetching variables for process ${processId}:`, error);
            return null;
        }
    };

    const fetchProcessesAndVariables = async () => {
        const formDemoProcesses = await fetchProcesses();


        if (!Array.isArray(formDemoProcesses)) {
            console.error('formDemoProcesses is not an array:', formDemoProcesses);
            setProcessesWithVariables([]);
            return;
        }

        if (formDemoProcesses.length === 0) {
            console.log('No form-demo processes found');
            setProcessesWithVariables([]);
            return;
        }

        const processesWithVars = await Promise.all(
            formDemoProcesses.map(async (process) => {
                const variables = await fetchProcessVariables(process.key);
                const tasks = await fetchTasks(process.key);
                const taskName = tasks.length > 0 ? tasks[0].name : null;
                const assignee = tasks.length > 0 ? tasks[0].assignee : null;
                return {
                    ...process,
                    variables,
                    taskName,
                    assignee
                };
            })
        );
        console.log(processesWithVars);
        setProcessesWithVariables(processesWithVars);
    };

    const processModel = {
        state: "CREATED",
        processInstanceKey: "",
        implementation: "JOB_WORKER"
    };
    const fetchTasks = async (processId) => {
        try {
            processModel.processInstanceKey = processId;
            const tok = undefined == keycloak.token ? token : keycloak.token
            const response = await axios.post(`http://localhost:8082/v1/tasks/search`, processModel, {
                headers: {
                    Authorization: `Bearer ${tok}`
                }
            });
            return response.data;
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };
    const sortData = (data, column, direction) => {
        return [...data].sort((a, b) => {
            const aValue = findNameByValue(a.variables.items, 'name', column) || '';
            const bValue = findNameByValue(b.variables.items, 'name', column) || '';
            if (direction === 'asc') {
                return aValue.localeCompare(bValue);
            } else {
                return bValue.localeCompare(aValue);
            }
        });
    };

    const filterData = (data, filters) => {
        return data.filter(task => {
            return Object.entries(filters).every(([key, value]) => {
                const taskValue = findNameByValue(task.variables.items, 'name', key) || '';
                return taskValue.toLowerCase().includes(value.toLowerCase());
            });
        });
    };
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleSearchChange = (event) => {
        setSearch(event.target.value);
        setPage(0);
    };
    const handleSort = (column) => {
        setSortDirection(sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc');
        setSortColumn(column);
    };

    const handleFilter = (column, value) => {
        setFilters(prev => ({ ...prev, [column]: value }));
        setPage(0);
    };
    if (!isAuthenticated) {
        return <div>Loading...</div>;
    }
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);

        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
    function findNameByValue(list, key, value) {
        const foundObject = list.find(obj => obj[key] === value);
        return foundObject ? foundObject.value.replace(/"/g, '') : null;
    }
    function showButton(user, tName, assignee) {
        if ((user.role == 'fauser' && tName == 'FA Approval') || (user.role == 'dbduser' && tName == 'DBD Approval') || (user.role == 'houser' && tName == 'Home Office Approval')) {
            if ((assignee == null) || (assignee != user.username)) {
                return true;
            }
        }
        return false;
    }
    return (
        <Container maxWidth="lg">
            <Paper elevation={3} sx={{ my: 4, p: 2, overflowX: 'auto' }}>
                <Box sx={{ mb: 2 }}>
                    <Tooltip title="Refresh">
                        <IconButton onClick={fetchProcessesAndVariables} color="primary" aria-label="refresh">
                            <RefreshIcon />
                        </IconButton>
                    </Tooltip>
                </Box>
                <div>
                    {user ? (
                        <p>Welcome, {user.username}! Your role is: {user.role}</p>
                    ) : (

                        navigate('/login')
                    )}
                </div>
                <TableContainer>
                    <Table sx={{ minWidth: 650, tableLayout: 'fixed' }}>
                        <TableHead sx={{ backgroundColor: "#0C3752" }}>
                            <TableRow>
                                {columns.map((column) => (
                                    <StyledTableCell key={column.id}>
                                        <Grid container direction="column" spacing={1}>
                                            <Grid item>
                                                <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }} onClick={() => handleSort(column.id)}>
                                                    {column.label}
                                                    {sortColumn === column.id && (
                                                        <ArrowDropUp sx={{ transform: sortDirection === 'desc' ? 'rotate(180deg)' : 'none' }} />
                                                    )}
                                                </Box>
                                            </Grid>
                                        </Grid>
                                    </StyledTableCell>
                                ))}
                            </TableRow>
                            <TableRow>
                                {columns.map((column) => (
                                    <StyledTableCell key={column.id}>
                                        <Grid container direction="column" spacing={1}>
                                            <Grid item>
                                                <TextField
                                                    size="small"
                                                    variant="outlined"
                                                    placeholder={`Filter ${column.label}`}
                                                    onChange={(e) => handleFilter(column.id, e.target.value)}
                                                    value={filters[column.id] || ''}
                                                    sx={{
                                                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                                                        width: '100%',
                                                        '& .MuiOutlinedInput-root': {
                                                            height: '28px',
                                                            fontSize: '0.75rem',
                                                        },
                                                        '& .MuiOutlinedInput-input': {
                                                            padding: '4px 8px',
                                                        },
                                                    }}
                                                />
                                            </Grid>
                                        </Grid>
                                    </StyledTableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {sortData(filterData(processesWithVariables, filters), sortColumn, sortDirection)
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((task, index) => (

                                    <StyledTableRow key={index}>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'clientFirstName') + ' ' + findNameByValue(task.variables.items, 'name', 'clientLastName')}</TableCell>
                                        <TableCell>Investment Objective Change</TableCell>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'accountNumber')}</TableCell>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'approvingWealthManager')}</TableCell>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'division')}</TableCell>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'branch')}</TableCell>
                                        <TableCell>{findNameByValue(task.variables.items, 'name', 'firstName') + ' ' + findNameByValue(task.variables.items, 'name', 'lastName')}</TableCell>
                                        <TableCell>{formatTimestamp(task.startDate)}</TableCell>
                                        <TableCell>{null == task.assignee ? (null != task.taskName ? task.taskName.replace('Approval', 'Team') : '') : task.assignee}</TableCell>
                                        <TableCell>{null == task.taskName ? task.state : 'Pending ' + task.taskName}</TableCell>
                                        <TableCell>
                                            {null != user && showButton(user, task.taskName, task.assignee) && (
                                                <Button
                                                    variant="contained"
                                                    color="primary"
                                                    size="small"
                                                    component={RouterLink}
                                                    to={`/process/${task.key}`}
                                                    style={{ marginRight: '8px' }}
                                                >
                                                    Assign
                                                </Button>

                                            )}
                                            {null != user && !showButton(user, task.taskName, task.assignee) && (
                                                <Button
                                                    variant="contained"
                                                    color="primary"
                                                    size="small"
                                                    component={RouterLink}
                                                    to={`/process/view/${task.key}`}
                                                    style={{ marginRight: '8px' }}
                                                >
                                                    View
                                                </Button>

                                            )}
                                        </TableCell>


                                    </StyledTableRow>
                                ))}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[25, 50]}
                    component="div"
                    count={filterData(processesWithVariables, filters).length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </Paper>
        </Container>
    );
};

export default TaskListView;