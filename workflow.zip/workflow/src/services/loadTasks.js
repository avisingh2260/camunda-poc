import axios from 'axios';

class ProcessInstanceModel {
  constructor(data) {
    this.items = data.items || [];
    this.sortValues = data.sortValues || [];
    this.total = data.total || 0;
  }
}

async function getToken() {
    try {
      const response = await axios.post('http://localhost:8084/oauth/token', 
        new URLSearchParams({
          'grant_type': 'password',
            'username': 'demo',
            'password': 'demo',
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      
      return response.data.access_token;
    } catch (error) {
      console.error('Error getting token:', error);
      throw error;
    }
  }
  

export const fetchProcessInstances = async (url, requestBody = {}) => {
    try {
    const token = await getToken();
    const response = await axios.get('http://localhost:8081/v1/processes', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.status === 200) {
        const data = response.data;
        return new ProcessInstanceModel(data);
      } else {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (error) {
      console.error("Error fetching process instances:", error);
      throw error;
    }
  };