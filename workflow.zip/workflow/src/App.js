import  React,{ useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Toolbar, Typography, Button, Container } from '@mui/material';
import{ AppBar } from 'stp001-mui-toolkit'
import { createTheme, ThemeProvider } from '@mui/material/styles';
import TaskListView from './components/TaskListView';
import SubmissionForm from './components/SubmissionForm';
import { initKeycloak, keycloak  } from './components/keycloak.js';
import Logo from "./assets/steward-logo.svg";
import LoginPage from './components/LoginPage.js';
import Header from './components/header.js';
import { AuthProvider } from './services/AuthContext.js';
const theme = createTheme({
    palette: {
        primary: {
            main: '#2A7CB5',
        },
    },
    components: {
        MuiContainer: {
          styleOverrides: {
            root: {
              maxWidth: 'none !important',
            },
          },
        },
      },
});

function App() {
    const [keycloakInitialized, setKeycloakInitialized] = useState(false);
    React.useEffect(() => {
        initKeycloak()
            .then((authenticated) => {
                setKeycloakInitialized(true);
                initializeTokenRefresh();
            })
            .catch((error) => {
                console.error('Keycloak initialization error:', error);
            });
    }, []);
    const initializeTokenRefresh = () => {
        setInterval(() => {
            keycloak.updateToken(70).then((refreshed) => {
                if (refreshed) {
                    console.log('Token refreshed' + refreshed);
                } else {
                    console.log('Token not refreshed, valid for '
                        + Math.round(keycloak.tokenParsed.exp + keycloak.timeSkew - new Date().getTime() / 1000) + ' seconds');
                }
            }).catch(() => {
                console.error('Failed to refresh token');
            });
        }, 60000); // Refresh token every minute
    };
    if (!keycloakInitialized) {
        return <div>Loading...</div>;
    }
    return (
        <AuthProvider>
            <ThemeProvider theme={theme}>
                <Router>
                    <Header />
                    <Container maxWidth="lg" style={{ marginTop: '2rem' }}>
                        <Routes>
                            <Route path="/" element={<TaskListView />} />
                            <Route path="/form" element={<SubmissionForm />} />
                            <Route path="/login" element={<LoginPage />} />
                            <Route path="/process/:id" element={<SubmissionForm />} />
                            <Route path="/process/view/:id" element={<SubmissionForm />} />
                        </Routes>
                    </Container>
                </Router>
            </ThemeProvider>
        </AuthProvider>
    );
}

export default App;