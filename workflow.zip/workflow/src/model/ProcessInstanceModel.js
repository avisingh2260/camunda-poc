class ProcessInstanceModel {
    constructor() {
      this.items = [
        {
          key: 0,
          processVersion: 0,
          bpmnProcessId: '',
          parentKey: 0,
          parentFlowNodeInstanceKey: 0,
          startDate: '',
          endDate: '',
          state: '',
          incident: false,
          processDefinitionKey: 0,
          tenantId: '',
          parentProcessInstanceKey: ''
        }
      ];
      this.sortValues = [{}];
      this.total = 0;
    }
  }