export function createProcessVariablesQuery(processInstanceKey) {
    const query = {
        filter: {
            processInstanceKey: processInstanceKey
        },
        size: 20,
        toJSON: function () {
            return {
                filter: this.filter,
                size:this.size
            };
        }
    };

    return query;
}

export function createProcessQuery() {
    const query = {
        filter: {
            bpmnProcessId: "form-demo"
        },
        size: "100",
        sort: [
            {
                field: "startDate",
                order: "DESC"
            }
        ],
        toJSON: function () {
            return {
                filter: this.filter,
                size: this.size,
                sort: this.sort
            };
        }
    };
    return query;
}